package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String Name = request.getParameter("name");
		String Email = request.getParameter("email");
		String Password = request.getParameter("pass");
		String Confirm_password = request.getParameter("re_pass");
		String Contact = request.getParameter("contact");
		
		RequestDispatcher dispatcher = null;
		
		String INSERT_SQL_QUERY = "INSERT INTO login(name,email,Password,confirm_password,contact_no) VALUES  ('"+Name+"','"+Email+"','"+Password+"','"+Confirm_password+"','"+Contact+"');";
		//String INSERT_SQL_QUERY = "INSERT INTO login(name,email,Password,confirm_password,contact_no) VALUES  ('Dharanish','Dharanis9751@gmail.com','123','123','6379277950');";
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String db_Host="192.168.5.57";
            String db_Port="1433";
            String db_User="sa";
            String db_Password="welcome!23";
            String db_Database ="web_page";

			try (Connection conn = DriverManager.getConnection("jdbc:sqlserver://"+db_Host+":"+db_Port+";user="+db_User+";password="+db_Password+";database="+db_Database);) {

				PreparedStatement PreparedStatement = conn.prepareStatement(INSERT_SQL_QUERY);
				
				int rowCount = PreparedStatement.executeUpdate();
				
				dispatcher = request.getRequestDispatcher("registration.jsp");
							 
				 if(rowCount > 0) {
					 
					 request.setAttribute("status", "success");
					 
				 }else {
					 
					 request.setAttribute("status", "failed");
				 }
				
				 dispatcher.forward(request, response);
				 
				 
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
